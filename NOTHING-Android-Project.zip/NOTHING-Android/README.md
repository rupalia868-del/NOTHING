# NOTHING — tiny blank Android app

This project builds a minimal Android app named **NOTHING** (`com.b9.nothing`).
It opens to a plain white screen and requests no Android permissions.

## Build it without installing Android Studio (GitHub Actions)

1. Create or sign in to a GitHub account.
2. Create a new **public** repository named `NOTHING` (public is easiest for this guide).
3. Extract this ZIP on your phone or computer.
4. Upload the *contents* of this folder to the repository root (so `app/`, `build.gradle`,
   `settings.gradle`, and `.github/` are at the top level).
5. Open the repository's **Actions** tab.
6. If GitHub asks, choose **I understand my workflows, go ahead and enable them**.
7. Open **Build NOTHING APK** on the left, tap **Run workflow**, then **Run workflow** again.
8. Wait for the run to finish with a green check.
9. Open that completed run, scroll to **Artifacts**, and download `NOTHING-debug-apk`.
10. Extract the downloaded ZIP. Inside is `app-debug.apk`.
11. Transfer `app-debug.apk` to your Android phone and tap it to install.
12. If Android blocks it, allow **Install unknown apps** for the app you used to open the APK,
    then retry. Only install APKs you built yourself or trust.

## Notes

- The APK is debug-signed automatically by Android Gradle Plugin, so it can be installed.
- Debug APKs are for personal testing, not Play Store publishing.
- The app has no network permission, no ads, and no tracking code.
- The app displays a plain white screen. It is not a transparent/zero-byte app.
- APK size depends on the Android build tools; this project aims to keep it very small,
  but the final size can only be confirmed after GitHub builds it.
- The GitHub Actions artifact is retained for 14 days. Download it before it expires.
