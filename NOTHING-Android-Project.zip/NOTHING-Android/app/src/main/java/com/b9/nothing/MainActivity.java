package com.b9.nothing;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View blank = new View(this);
        blank.setBackgroundColor(0xFFFFFFFF);
        setContentView(blank);
    }
}
